const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // Remove authentication from connection string and use simple local connection
    const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/photography_booking';
    
    const conn = await mongoose.connect(mongoURI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB Connection Error: ${error.message}`);
    console.log('\nTroubleshooting tips:');
    console.log('1. Make sure MongoDB is installed and running');
    console.log('2. Check your .env file MONGODB_URI setting');
    console.log('3. Use: mongodb://127.0.0.1:27017/photography_booking for local MongoDB');
    process.exit(1);
  }
};

module.exports = connectDB;
