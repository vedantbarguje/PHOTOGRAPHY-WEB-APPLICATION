const express = require('express');
const router = express.Router();
const {
  createPackage,
  getPackages,
  getPackage,
  updatePackage,
  deletePackage
} = require('../controllers/packageController');
const { protect, isAdmin } = require('../middleware/auth');

router.route('/')
  .post(protect, isAdmin, createPackage)
  .get(getPackages);

router.route('/:id')
  .get(getPackage)
  .put(protect, isAdmin, updatePackage)
  .delete(protect, isAdmin, deletePackage);

module.exports = router;
