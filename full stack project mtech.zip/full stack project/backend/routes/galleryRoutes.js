const express = require('express');
const router = express.Router();
const {
  createGalleryItem,
  getGalleryItems,
  getGalleryItem,
  updateGalleryItem,
  deleteGalleryItem
} = require('../controllers/galleryController');
const { protect, isAdmin } = require('../middleware/auth');

router.route('/')
  .post(protect, isAdmin, createGalleryItem)
  .get(getGalleryItems);

router.route('/:id')
  .get(getGalleryItem)
  .put(protect, isAdmin, updateGalleryItem)
  .delete(protect, isAdmin, deleteGalleryItem);

module.exports = router;
