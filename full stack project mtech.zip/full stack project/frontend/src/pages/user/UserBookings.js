import React, { useState, useEffect } from 'react';
import { Calendar, Edit, Trash2, CheckCircle, Clock, XCircle } from 'lucide-react';
import Navbar from '../../components/Navbar';
import UserSidebar from '../../components/UserSidebar';
import { bookingAPI } from '../../services/api';
import toast from 'react-hot-toast';

const UserBookings = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const { data } = await bookingAPI.getAll();
      setBookings(data.data);
    } catch (error) {
      toast.error('Error fetching bookings');
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this booking?')) {
      try {
        await bookingAPI.delete(id);
        setBookings(bookings.filter(b => b._id !== id));
        toast.success('Booking deleted successfully');
      } catch (error) {
        toast.error('Error deleting booking');
      }
    }
  };

  const getStatusBadge = (status) => {
    const styles = {
      confirmed: 'bg-green-100 text-green-800',
      pending: 'bg-yellow-100 text-yellow-800',
      cancelled: 'bg-red-100 text-red-800',
      completed: 'bg-blue-100 text-blue-800'
    };
    return styles[status] || styles.pending;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <UserSidebar />
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">My Bookings</h1>
            <p className="text-gray-600">Manage all your photography bookings</p>
          </div>

          {bookings.length === 0 ? (
            <div className="card p-12 text-center">
              <Calendar className="h-20 w-20 text-gray-300 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">No Bookings Yet</h2>
              <p className="text-gray-600 mb-6">Start by creating your first booking</p>
              <a
                href="/user/create-booking"
                className="inline-block px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg font-semibold hover:shadow-xl transition-all"
              >
                Create Booking
              </a>
            </div>
          ) : (
            <div className="grid gap-6">
              {bookings.map((booking) => (
                <div key={booking._id} className="card p-6 hover:shadow-xl transition-all">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div className="flex-1 mb-4 md:mb-0">
                      <div className="flex items-center space-x-3 mb-3">
                        <h3 className="text-2xl font-bold text-gray-900 capitalize">
                          {booking.packageType} Photography
                        </h3>
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusBadge(booking.status)}`}>
                          {booking.status}
                        </span>
                      </div>
                      <div className="grid md:grid-cols-2 gap-4 text-gray-600">
                        <div className="flex items-center space-x-2">
                          <Calendar className="h-5 w-5" />
                          <span>{new Date(booking.date).toLocaleDateString()} at {booking.time}</span>
                        </div>
                        <div>
                          <span className="font-medium">Location:</span> {booking.location}
                        </div>
                        <div>
                          <span className="font-medium">Duration:</span> {booking.duration}
                        </div>
                        <div>
                          <span className="font-medium text-blue-600 text-lg">
                            Price: ${booking.price}
                          </span>
                        </div>
                      </div>
                      {booking.notes && (
                        <p className="mt-3 text-gray-600">
                          <span className="font-medium">Notes:</span> {booking.notes}
                        </p>
                      )}
                    </div>
                    <div className="flex space-x-3">
                      <button
                        onClick={() => handleDelete(booking._id)}
                        className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default UserBookings;
