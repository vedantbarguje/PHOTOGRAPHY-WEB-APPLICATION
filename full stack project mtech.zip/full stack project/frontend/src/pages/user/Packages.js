import React, { useState, useEffect } from 'react';
import { Check, Package as PackageIcon } from 'lucide-react';
import Navbar from '../../components/Navbar';
import UserSidebar from '../../components/UserSidebar';
import { packageAPI } from '../../services/api';
import { useNavigate } from 'react-router-dom';

const Packages = () => {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchPackages();
  }, []);

  const fetchPackages = async () => {
    try {
      const { data } = await packageAPI.getAll();
      setPackages(data.data);
    } catch (error) {
      console.error('Error fetching packages:', error);
    } finally {
      setLoading(false);
    }
  };

  const getCategoryColor = (category) => {
    const colors = {
      wedding: 'from-pink-500 to-purple-500',
      portrait: 'from-blue-500 to-cyan-500',
      event: 'from-yellow-500 to-orange-500',
      commercial: 'from-green-500 to-teal-500',
      other: 'from-gray-500 to-gray-700'
    };
    return colors[category] || colors.other;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <UserSidebar />
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Photography Packages</h1>
            <p className="text-gray-600">Choose the perfect package for your needs</p>
          </div>

          {packages.length === 0 ? (
            <div className="card p-12 text-center">
              <PackageIcon className="h-20 w-20 text-gray-300 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">No Packages Available</h2>
              <p className="text-gray-600">Check back later for available packages</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {packages.map((pkg) => (
                <div
                  key={pkg._id}
                  className="card overflow-hidden hover:shadow-2xl transition-all duration-300"
                >
                  <div className={`h-40 bg-gradient-to-br ${getCategoryColor(pkg.category)} flex items-center justify-center`}>
                    {pkg.imageUrl ? (
                      <img src={pkg.imageUrl} alt={pkg.name} className="w-full h-full object-cover" />
                    ) : (
                      <PackageIcon className="h-20 w-20 text-white opacity-50" />
                    )}
                  </div>

                  <div className="p-6">
                    <div className="mb-4">
                      <span className="px-3 py-1 bg-blue-100 text-blue-800 text-xs font-semibold rounded-full uppercase">
                        {pkg.category}
                      </span>
                    </div>

                    <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                    <p className="text-gray-600 mb-4">{pkg.description}</p>

                    <div className="flex items-baseline mb-6">
                      <span className="text-4xl font-bold text-blue-600">${pkg.price}</span>
                      <span className="text-gray-600 ml-2">/ {pkg.duration}</span>
                    </div>

                    {pkg.features && pkg.features.length > 0 && (
                      <div className="mb-6 space-y-3">
                        {pkg.features.map((feature, index) => (
                          <div key={index} className="flex items-start space-x-2">
                            <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700">{feature}</span>
                          </div>
                        ))}
                      </div>
                    )}

                    <button
                      onClick={() => navigate('/user/create-booking')}
                      className="w-full btn-primary"
                    >
                      Book Now
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Packages;
