import React, { useState, useEffect } from 'react';
import { Users, Calendar, Package, Image, TrendingUp } from 'lucide-react';
import Navbar from '../../components/Navbar';
import AdminSidebar from '../../components/AdminSidebar';
import { bookingAPI, packageAPI, userAPI, galleryAPI } from '../../services/api';

const AdminDashboard = () => {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalBookings: 0,
    totalPackages: 0,
    totalGalleryItems: 0,
    pendingBookings: 0,
    confirmedBookings: 0,
    revenue: 0
  });
  const [recentBookings, setRecentBookings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      const [usersRes, bookingsRes, packagesRes, galleryRes] = await Promise.all([
        userAPI.getAll(),
        bookingAPI.getAll(),
        packageAPI.getAll(),
        galleryAPI.getAll()
      ]);

      const bookings = bookingsRes.data.data;
      const revenue = bookings.reduce((sum, booking) => sum + Number(booking.price), 0);

      setStats({
        totalUsers: usersRes.data.count,
        totalBookings: bookings.length,
        totalPackages: packagesRes.data.count,
        totalGalleryItems: galleryRes.data.count,
        pendingBookings: bookings.filter(b => b.status === 'pending').length,
        confirmedBookings: bookings.filter(b => b.status === 'confirmed').length,
        revenue
      });

      setRecentBookings(bookings.slice(0, 5));
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { label: 'Total Users', value: stats.totalUsers, icon: Users, color: 'blue', bgColor: 'bg-blue-500' },
    { label: 'Total Bookings', value: stats.totalBookings, icon: Calendar, color: 'purple', bgColor: 'bg-purple-500' },
    { label: 'Packages', value: stats.totalPackages, icon: Package, color: 'green', bgColor: 'bg-green-500' },
    { label: 'Gallery Items', value: stats.totalGalleryItems, icon: Image, color: 'pink', bgColor: 'bg-pink-500' },
    { label: 'Pending Bookings', value: stats.pendingBookings, icon: Calendar, color: 'yellow', bgColor: 'bg-yellow-500' },
    { label: 'Confirmed', value: stats.confirmedBookings, icon: Calendar, color: 'teal', bgColor: 'bg-teal-500' },
    { label: 'Total Revenue', value: `$${stats.revenue}`, icon: TrendingUp, color: 'indigo', bgColor: 'bg-indigo-500', span: 'md:col-span-2' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 p-8">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Manage your photography business</p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statCards.map((stat, index) => (
              <div
                key={index}
                className={`card p-6 hover:shadow-xl transition-all ${stat.span || ''}`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-600 text-sm font-medium mb-2">{stat.label}</p>
                    <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  </div>
                  <div className={`p-4 ${stat.bgColor} rounded-xl`}>
                    <stat.icon className="h-8 w-8 text-white" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Recent Bookings */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Recent Bookings</h2>
              <a
                href="/admin/bookings"
                className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
              >
                View All
              </a>
            </div>

            {recentBookings.length === 0 ? (
              <div className="text-center py-8 text-gray-600">No bookings yet</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Client</th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Package</th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Date</th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Status</th>
                      <th className="text-left py-3 px-4 font-semibold text-gray-700">Price</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentBookings.map((booking) => (
                      <tr key={booking._id} className="border-b hover:bg-gray-50">
                        <td className="py-4 px-4">{booking.user?.name || 'N/A'}</td>
                        <td className="py-4 px-4 capitalize">{booking.packageType}</td>
                        <td className="py-4 px-4">
                          {new Date(booking.date).toLocaleDateString()}
                        </td>
                        <td className="py-4 px-4">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                            booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                            booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {booking.status}
                          </span>
                        </td>
                        <td className="py-4 px-4 font-semibold">${booking.price}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminDashboard;
