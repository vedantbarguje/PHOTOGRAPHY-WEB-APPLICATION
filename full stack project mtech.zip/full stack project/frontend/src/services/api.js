import axios from 'axios';

const API_URL = '/api';

// Auth API
export const authAPI = {
  register: (data) => axios.post(`${API_URL}/auth/register`, data),
  login: (data) => axios.post(`${API_URL}/auth/login`, data),
  getMe: () => axios.get(`${API_URL}/auth/me`),
};

// Booking API
export const bookingAPI = {
  create: (data) => axios.post(`${API_URL}/bookings`, data),
  getAll: () => axios.get(`${API_URL}/bookings`),
  getById: (id) => axios.get(`${API_URL}/bookings/${id}`),
  update: (id, data) => axios.put(`${API_URL}/bookings/${id}`, data),
  delete: (id) => axios.delete(`${API_URL}/bookings/${id}`),
};

// Package API
export const packageAPI = {
  create: (data) => axios.post(`${API_URL}/packages`, data),
  getAll: () => axios.get(`${API_URL}/packages`),
  getById: (id) => axios.get(`${API_URL}/packages/${id}`),
  update: (id, data) => axios.put(`${API_URL}/packages/${id}`, data),
  delete: (id) => axios.delete(`${API_URL}/packages/${id}`),
};

// Gallery API
export const galleryAPI = {
  create: (data) => axios.post(`${API_URL}/gallery`, data),
  getAll: (params) => axios.get(`${API_URL}/gallery`, { params }),
  getById: (id) => axios.get(`${API_URL}/gallery/${id}`),
  update: (id, data) => axios.put(`${API_URL}/gallery/${id}`, data),
  delete: (id) => axios.delete(`${API_URL}/gallery/${id}`),
};

// User API
export const userAPI = {
  getAll: () => axios.get(`${API_URL}/users`),
  getById: (id) => axios.get(`${API_URL}/users/${id}`),
  update: (id, data) => axios.put(`${API_URL}/users/${id}`, data),
  delete: (id) => axios.delete(`${API_URL}/users/${id}`),
};
