import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Home, Calendar, Package, Image } from 'lucide-react';

const UserSidebar = () => {
  const location = useLocation();

  const links = [
    { to: '/user/dashboard', icon: Home, label: 'Dashboard' },
    { to: '/user/bookings', icon: Calendar, label: 'My Bookings' },
    { to: '/user/packages', icon: Package, label: 'Packages' },
    { to: '/user/gallery', icon: Image, label: 'Gallery' },
  ];

  return (
    <aside className="w-64 bg-gradient-to-b from-blue-600 to-purple-600 min-h-screen text-white">
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-8">User Panel</h2>
        <nav className="space-y-2">
          {links.map(({ to, icon: Icon, label }) => (
            <Link
              key={to}
              to={to}
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                location.pathname === to
                  ? 'bg-white text-blue-600 shadow-lg'
                  : 'hover:bg-white/10'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="font-medium">{label}</span>
            </Link>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default UserSidebar;
