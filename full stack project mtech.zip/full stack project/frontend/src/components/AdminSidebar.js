import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, Calendar, Package, Image, Users } from 'lucide-react';

const AdminSidebar = () => {
  const location = useLocation();

  const links = [
    { to: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/admin/bookings', icon: Calendar, label: 'Bookings' },
    { to: '/admin/packages', icon: Package, label: 'Packages' },
    { to: '/admin/gallery', icon: Image, label: 'Gallery' },
    { to: '/admin/users', icon: Users, label: 'Users' },
  ];

  return (
    <aside className="w-64 bg-gradient-to-b from-gray-900 to-gray-800 min-h-screen text-white">
      <div className="p-6">
        <h2 className="text-2xl font-bold mb-8">Admin Panel</h2>
        <nav className="space-y-2">
          {links.map(({ to, icon: Icon, label }) => (
            <Link
              key={to}
              to={to}
              className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
                location.pathname === to
                  ? 'bg-white text-gray-900 shadow-lg'
                  : 'hover:bg-white/10'
              }`}
            >
              <Icon className="h-5 w-5" />
              <span className="font-medium">{label}</span>
            </Link>
          ))}
        </nav>
      </div>
    </aside>
  );
};

export default AdminSidebar;
